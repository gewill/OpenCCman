import AppKit
import ScreenCaptureKit
import AVFoundation

final class RecordingDelegate: NSObject, SCRecordingOutputDelegate {
  var finished = false
  func recordingOutputDidStartRecording(_ output: SCRecordingOutput) { print("recording_started"); fflush(stdout) }
  func recordingOutputDidFinishRecording(_ output: SCRecordingOutput) { finished = true }
  func recordingOutput(_ output: SCRecordingOutput, didFailWithError error: Error) {
    fputs("recording_failed: \(error)\n", stderr); exit(2)
  }
}
@main struct Recorder {
  static func main() async throws {
    let pid = Int32(CommandLine.arguments[1])!
    var selected: (SCRunningApplication, SCDisplay)?
    for _ in 0..<100 {
      let content = try await SCShareableContent.excludingDesktopWindows(true, onScreenWindowsOnly: true)
      if let app = content.applications.first(where: { $0.processID == pid }), let display = content.displays.first {
        selected = (app, display); break
      }
      try await Task.sleep(for: .milliseconds(100))
    }
    guard let (app, display) = selected else { fatalError("Missing diagnostic app/display") }
    let filter = SCContentFilter(display: display, including: [app], exceptingWindows: [])
    let config = SCStreamConfiguration()
    config.width = 1280
    config.height = 720
    config.minimumFrameInterval = CMTime(value: 1, timescale: 10)
    config.capturesAudio = false
    config.showsCursor = false
    let stream = SCStream(filter: filter, configuration: config, delegate: nil)
    let outputConfig = SCRecordingOutputConfiguration()
    outputConfig.outputURL = URL(fileURLWithPath: CommandLine.arguments[2])
    outputConfig.outputFileType = .mp4
    outputConfig.videoCodecType = .h264
    let delegate = RecordingDelegate()
    let output = SCRecordingOutput(configuration: outputConfig, delegate: delegate)
    try stream.addRecordingOutput(output)
    try await stream.startCapture()
    try await Task.sleep(for: .seconds(Double(CommandLine.arguments[3])!))
    try await stream.stopCapture()
    for _ in 0..<100 {
      if delegate.finished { print("recording_finished"); return }
      try await Task.sleep(for: .milliseconds(100))
    }
    fatalError("Recording did not finish")
  }
}
