import ApplicationServices
import Foundation
let app = AXUIElementCreateApplication(pid_t(CommandLine.arguments[1])!)
var held:[AXUIElement] = []
func read(_ element: AXUIElement, _ depth:Int) {
 guard depth<8 else{return};held.append(element)
 var children:CFTypeRef?
 if AXUIElementCopyAttributeValue(element,kAXChildrenAttribute as CFString,&children) == .success,
 let children=children as? [AXUIElement] { for child in children {read(child,depth+1)} }
}
func query(){
 var windows:CFTypeRef?
 let status=AXUIElementCopyAttributeValue(app,kAXWindowsAttribute as CFString,&windows)
 if let windows=windows as? [AXUIElement]{for w in windows{read(w,0)}}
 print("queried",status.rawValue,"held",held.count);fflush(stdout)
}
query();Thread.sleep(forTimeInterval:10);query()
Thread.sleep(forTimeInterval:50)
held.removeAll();print("released all retained AX elements");fflush(stdout)
Thread.sleep(forTimeInterval:15)
