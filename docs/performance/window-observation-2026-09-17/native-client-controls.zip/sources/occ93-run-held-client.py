import subprocess,glob,pathlib,json,time
out=pathlib.Path('/tmp/occ93-client-hold-results');out.mkdir(exist_ok=False)
known=set(glob.glob('/var/folders/*/*/T/OpenCCman-MinimalLifetime-*.jsonl'));start=time.monotonic()
subprocess.run(['open','-n','/tmp/occ93-client-hold-20260917/AXHoldProbe.app'],check=True)
while time.monotonic()-start<8:
 found=set(glob.glob('/var/folders/*/*/T/OpenCCman-MinimalLifetime-*.jsonl'))-known
 if found:log=pathlib.Path(found.pop());break
 time.sleep(.1)
pid=log.stem.rsplit('-',1)[1]
time.sleep(max(0,start+3-time.monotonic()))
with (out/'client.log').open('w') as f:
 client=subprocess.Popen(['/tmp/occ93-ax-hold',pid],stdout=f,stderr=f)
while time.monotonic()-start<110:
 rows=list(map(json.loads,log.read_text().splitlines()))
 if rows[-1]['event']=='driver_finished':break
 time.sleep(.5)
client.wait(timeout=5)
(out/'fixture.jsonl').write_text(log.read_text());print(pid,[(r['event'],r['alive']) for r in rows if 'plus_' in r['event']]);print((out/'client.log').read_text())
