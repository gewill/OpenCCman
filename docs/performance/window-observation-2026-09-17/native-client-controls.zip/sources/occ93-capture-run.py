import pathlib,subprocess,time,json,glob,os
out=pathlib.Path('/tmp/occ93-capture-20260917');out.mkdir(exist_ok=False)
app='/tmp/occ93-baseline-20260917/MinimalTextAutoHosts.app'
for mode in ['window-capture']:
 known=set(glob.glob('/var/folders/*/*/T/OpenCCman-MinimalLifetime-*.jsonl'))
 launched=time.monotonic();subprocess.run(['open','-n',app],check=True)
 log=None
 while time.monotonic()-launched<8:
  found=set(glob.glob('/var/folders/*/*/T/OpenCCman-MinimalLifetime-*.jsonl'))-known
  if found:log=pathlib.Path(found.pop());break
  time.sleep(.1)
 if not log:raise RuntimeError('no log')
 pid=log.stem.rsplit('-',1)[1];queries=[]
 for offset in [3,13]:
  time.sleep(max(0,launched+offset-time.monotonic()))
  if mode=='window-capture':
   ids=subprocess.check_output(['/tmp/occ93-window-ids',pid],text=True).split()
   assert len(ids)==(1 if offset==3 else 2),ids
   q=subprocess.run(['/usr/sbin/screencapture','-x','-l'+ids[0],str(out/f'window-{offset}.png')],capture_output=True,text=True,timeout=5)
   if q.returncode:raise RuntimeError(q.stderr)
   queries.append({'elapsed':time.monotonic()-launched,'exit':q.returncode,'output':q.stdout,'stderr':q.stderr})
 while time.monotonic()-launched<85:
  lines=log.read_text().splitlines()
  if lines and json.loads(lines[-1])['event']=='driver_finished':break
  time.sleep(.5)
 rows=[json.loads(l) for l in log.read_text().splitlines()]
 (out/(mode+'.jsonl')).write_text(log.read_text());(out/(mode+'-queries.json')).write_text(json.dumps(queries,indent=2))
 print(mode,pid,[(d['event'],d['alive']) for d in rows if 'plus_' in d['event']],queries,flush=True)
 if rows[-1]['event']!='driver_finished':raise RuntimeError('run incomplete')
 time.sleep(1)
