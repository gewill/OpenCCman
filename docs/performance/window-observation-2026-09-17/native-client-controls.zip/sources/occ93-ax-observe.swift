import ApplicationServices
import Foundation
let pid=pid_t(CommandLine.arguments[1])!
let app=AXUIElementCreateApplication(pid)
var observer:AXObserver?
func callback(_ observer:AXObserver,_ element:AXUIElement,_ notification:CFString,_ refcon:UnsafeMutableRawPointer?){ }
let created=AXObserverCreate(pid,callback,&observer)
print("observer",created.rawValue);guard let observer else{exit(2)}
CFRunLoopAddSource(CFRunLoopGetCurrent(),AXObserverGetRunLoopSource(observer),.defaultMode)
var registered:[(AXUIElement,String)]=[]
let names=[kAXUIElementDestroyedNotification,kAXValueChangedNotification,kAXFocusedUIElementChangedNotification,kAXFocusedWindowChangedNotification,kAXMainWindowChangedNotification,kAXWindowCreatedNotification,kAXWindowMovedNotification,kAXWindowResizedNotification]
func read(_ e:AXUIElement,_ depth:Int){
 guard depth<8 else{return}
 for name in names {
  if AXObserverAddNotification(observer,e,name as CFString,nil) == .success{registered.append((e,name))}
 }
 var children:CFTypeRef?
 if AXUIElementCopyAttributeValue(e,kAXChildrenAttribute as CFString,&children) == .success,let cs=children as? [AXUIElement]{for c in cs{read(c,depth+1)}}
}
func wait(_ seconds:Double){let end=Date().addingTimeInterval(seconds);while Date()<end{CFRunLoopRunInMode(.defaultMode,min(0.1,end.timeIntervalSinceNow),false)}}
read(app,0);print("registered",registered.count);fflush(stdout)
wait(10);read(app,0);print("registered",registered.count);fflush(stdout)
wait(50)
for (element,name) in registered {_ = AXObserverRemoveNotification(observer,element,name as CFString)}
registered.removeAll();CFRunLoopRemoveSource(CFRunLoopGetCurrent(),AXObserverGetRunLoopSource(observer),.defaultMode)
print("removed registrations");fflush(stdout);wait(15)
