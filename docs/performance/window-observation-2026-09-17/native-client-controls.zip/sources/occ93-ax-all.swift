import ApplicationServices
import Foundation
let app=AXUIElementCreateApplication(pid_t(CommandLine.arguments[1])!)
if CommandLine.arguments.contains("--enhanced") {
 print("enableEnhanced",AXUIElementSetAttributeValue(app,"AXEnhancedUserInterface" as CFString,kCFBooleanTrue).rawValue)
}
var count=0
func read(_ e:AXUIElement,_ depth:Int){
 guard depth<8 else{return};count+=1
 var attributes:CFArray?
 if AXUIElementCopyAttributeNames(e,&attributes) == .success,let attrs=attributes as? [String] {
  for a in attrs { var v:CFTypeRef?;_ = AXUIElementCopyAttributeValue(e,a as CFString,&v) }
 }
 var children:CFTypeRef?
 if AXUIElementCopyAttributeValue(e,kAXChildrenAttribute as CFString,&children) == .success,let cs=children as? [AXUIElement]{ for c in cs {read(c,depth+1)} }
}
read(app,0);print("read elements",count)
