import ApplicationServices
import Foundation
let pid = pid_t(CommandLine.arguments[1])!
let app = AXUIElementCreateApplication(pid)
print("trusted", AXIsProcessTrusted())
var windows: CFTypeRef?
let status = AXUIElementCopyAttributeValue(app, kAXWindowsAttribute as CFString, &windows)
print("windowsStatus",status.rawValue)
func read(_ element: AXUIElement, _ depth: Int) {
 guard depth < 8 else { return }
 for name in [kAXRoleAttribute,kAXTitleAttribute] {
  var value: CFTypeRef?;let s=AXUIElementCopyAttributeValue(element,name as CFString,&value)
  if s == .success { print(depth,name,value ?? "nil" as CFString) }
 }
 var children: CFTypeRef?
 if AXUIElementCopyAttributeValue(element,kAXChildrenAttribute as CFString,&children) == .success,
 let children=children as? [AXUIElement] { for child in children { read(child,depth+1) } }
}
if let windows = windows as? [AXUIElement] {for window in windows {read(window,0)}}
