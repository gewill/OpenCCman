from pathlib import Path
import shutil,subprocess,plistlib
src=Path('/tmp/occ93-baseline-20260917');out=Path('/tmp/occ93-observers-20260917');shutil.copytree(src,out)
p=out/'Probe.swift';s=p.read_text().replace('guard now - began < 80','guard now - began < 130').replace('guard now - pairAt >= 10','guard now - pairAt >= 30')
s=s.replace('        finish(failed: nil)','''        if !removed {
          removed = true
          OCC93RemoveFixtureObservers()
        }
        if now - closedAt >= 25 { ProbeLog.shared.record("diagnostic_after_removal"); finish(failed: nil) }''')
s=s.replace('  private var recordedFive = false','  private var recordedFive = false\n  private var removed = false')
s+='\n@_silgen_name("OCC93RemoveFixtureObservers") func OCC93RemoveFixtureObservers()\n';p.write_text(s)
app=out/'ObserverProbe.app';(out/'MinimalTextAutoHosts.app').rename(app);info=app/'Contents/Info.plist';d=plistlib.loads(info.read_bytes());d['CFBundleIdentifier']='org.gewill.OpenCCman.ObserverProbe20260917';d['CFBundleName']='Lifetime Observer Probe';info.write_bytes(plistlib.dumps(d))
with (out/'build.log').open('w') as log:
 subprocess.run(['xcrun','clang','-fobjc-arc','-c','/tmp/occ93-observer-probe.m','-o',str(out/'probe.o')],check=True,stdout=log,stderr=log)
 subprocess.run(['xcrun','swiftc','-swift-version','5','-parse-as-library','-O','-target','arm64-apple-macosx13.0',str(p),str(out/'probe.o'),'-o',str(app/'Contents/MacOS/MinimalTextAutoHosts')],check=True,stdout=log,stderr=log)
subprocess.run(['codesign','--force','--sign','-',str(app)],check=True)
