from pathlib import Path
import shutil,plistlib,subprocess
base=Path('/tmp/occ93-baseline-20260917');out=Path('/tmp/occ93-gate-20260917');out.mkdir(exist_ok=False)
s=(base/'Probe.swift').read_text().replace('ProbeRoot().background(LifetimeDriverView())','LifetimeBoundary().background(LifetimeDriverView())')
s+='''
struct LifetimeBoundary: View {
  @State private var closed = false
  @State private var windowID: ObjectIdentifier?
  var body: some View {
    Group {
      if !closed { ProbeRoot() }
    }
    .background(BoundaryWindowReader { windowID = ObjectIdentifier($0) })
    .onReceive(NotificationCenter.default.publisher(for: NSWindow.willCloseNotification)) { notification in
      guard let window = notification.object as? NSWindow,
        ObjectIdentifier(window) == windowID else { return }
      closed = true
    }
  }
}
struct BoundaryWindowReader: NSViewRepresentable {
  var attached: (NSWindow) -> Void
  func makeNSView(context: Context) -> Reader { let r = Reader(); r.attached = attached; return r }
  func updateNSView(_ view: Reader, context: Context) { view.attached = attached }
  final class Reader: NSView {
    var attached: ((NSWindow) -> Void)?
    override func viewDidMoveToWindow() {
      super.viewDidMoveToWindow()
      guard let window else { return }
      DispatchQueue.main.async { [weak self, weak window] in
        guard let self, let window else { return }; self.attached?(window)
      }
    }
  }
}
'''
(out/'Probe.swift').write_text(s)
app=out/'LifetimeGate.app';shutil.copytree(base/'MinimalTextAutoHosts.app',app)
p=app/'Contents/Info.plist';d=plistlib.loads(p.read_bytes());d['CFBundleIdentifier']='org.gewill.OpenCCman.LifetimeGate20260917';d['CFBundleName']='Lifetime Gate Probe';p.write_bytes(plistlib.dumps(d))
subprocess.run(['xcrun','swiftc','-swift-version','5','-parse-as-library','-O','-target','arm64-apple-macosx13.0',str(out/'Probe.swift'),'-o',str(app/'Contents/MacOS/MinimalTextAutoHosts')],check=True)
subprocess.run(['codesign','--force','--sign','-',str(app)],check=True)
