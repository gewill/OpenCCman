#import <Foundation/Foundation.h>
#import <objc/runtime.h>
#include <stdio.h>
#include <unistd.h>
static NSHashTable *tokens;
static void record(NSString *message) {
 char path[160];snprintf(path,sizeof(path),"/tmp/occ93-observers-%d.log",getpid());
 FILE *f=fopen(path,"a");if(f){fprintf(f,"%s\n",message.UTF8String);fclose(f);}
}
@interface NSNotificationCenter (OCC93Probe)
@end
@implementation NSNotificationCenter (OCC93Probe)
+ (void)load {
 method_exchangeImplementations(class_getInstanceMethod(self,@selector(addObserverForName:object:queue:usingBlock:)),class_getInstanceMethod(self,@selector(occ93_addObserverForName:object:queue:usingBlock:)));
}
- (id)occ93_addObserverForName:(NSNotificationName)name object:(id)object queue:(NSOperationQueue *)queue usingBlock:(void (^)(NSNotification *))block {
 id token=[self occ93_addObserverForName:name object:object queue:queue usingBlock:block];
 NSArray *stack=[NSThread callStackSymbols];
 if([[stack componentsJoinedByString:@"\n"] containsString:@"_commonAwake"]){
  if(!tokens)tokens=[NSHashTable weakObjectsHashTable];
  [tokens addObject:token];
  record([NSString stringWithFormat:@"register name=%@ object=%p token=%p class=%@",name,object,token,NSStringFromClass([token class])]);
 }
 return token;
}
@end
void OCC93RemoveFixtureObservers(void) {
 record([NSString stringWithFormat:@"DIAGNOSTIC removal count=%lu",(unsigned long)tokens.count]);
 for(id token in tokens.allObjects)[[NSNotificationCenter defaultCenter] removeObserver:token];
 [tokens removeAllObjects];
}
