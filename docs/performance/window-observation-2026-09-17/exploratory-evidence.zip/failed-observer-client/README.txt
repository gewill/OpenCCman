Client compilation failed (.1 floating literal), so executable missing; fixture PID 39010 terminated explicitly. No acceptance result. Retried as PID 39245.
