OpenCC fork update

Candidate: `c75671b112ae7ff8cc08`

Base: `gewill/SwiftyOpenCC:master` at `c400ac932b960904ea1903715cb22dd572c2886b`

Wrapper upstream: `1d8105a0f7199c90af722bff62728050c858e777`
OpenCC: `ver.1.4.1` / `81223ed87ae53283ef518e2deac34b7971f8a39e` → `ver.1.4.2` / `025f371dc76b598d77384fbdab90c937471844d8`

Validation: 

Human review and merge required. Use **Create a merge commit** for fork updates.
To roll back, restore the app's prior pin in a PR; revert the complete fork update if needed.
Add `c75671b112ae7ff8cc08` to `ignoredCandidates.fork` in the coordinator configuration to suppress this candidate.

<!-- opencc-sync:v1 fork c75671b112ae7ff8cc08 -->

Failure: python3 failed: -- Configuring incomplete, errors occurred!

CMake Error at <TEMP>/opencc-sync-4xe7drb5/candidate/.build/pinned-cmake/cmake-4.4.3-macos10.10-universal/CMake.app/Contents/share/cmake-4.4/Modules/CMakeDetermineCXXCompiler.cmake:47 (message):
  Could not find the compiler specified in the environment variable CXX:

  
  <HOME>/git/MyApps/OpenCCman-upstream-validation/.build/real-sync/run-1/intentionally-missing-cxx.

Call Stack (most recent call first):
  CMakeLists.txt:22 (project)


CMake Error: CMAKE_CXX_COMPILER not set, after EnableLanguage
Command '['<TEMP>/opencc-sync-4xe7drb5/candidate/.build/pinned-cmake/cmake-4.4.3-macos10.10-universal/CMake.app/Contents/bin/cmake', '-S', '<TEMP>/opencc-sync-4xe7drb5/candidate/OpenCC', '-B', '<TEMP>/opencc-sync-4xe7drb5/candidate/.build/opencc-resources', '-G', 'Unix Makefiles', '-DCMAKE_BUILD_TYPE=Release', '-DBUILD_SHARED_LIBS=OFF', '-DBUILD_DOCUMENTATION=OFF', '-DBUILD_OPENCC_JIEBA_PLUGIN=OFF', '-DBUILD_PYTHON=OFF', '-DENABLE_GTEST=OFF', '-DENABLE_BENCHMARK=OFF', '-DOPENCC_DICT_FORMAT=ocd2', '-DOPENCC_ENABLE_INSTALL=OFF']' returned non-zero exit status 1.
