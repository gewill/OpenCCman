OpenCC fork update

Candidate: `c75671b112ae7ff8cc08`

Base: `gewill/SwiftyOpenCC:master` at `c400ac932b960904ea1903715cb22dd572c2886b`

Wrapper upstream: `1d8105a0f7199c90af722bff62728050c858e777`
OpenCC: `ver.1.4.1` / `81223ed87ae53283ef518e2deac34b7971f8a39e` → `ver.1.4.2` / `025f371dc76b598d77384fbdab90c937471844d8`

Validation: pinned resource generation, manifest --check, swift test, official CLI byte comparison

Human review and merge required. Use **Create a merge commit** for fork updates.
To roll back, restore the app's prior pin in a PR; revert the complete fork update if needed.
Add `c75671b112ae7ff8cc08` to `ignoredCandidates.fork` in the coordinator configuration to suppress this candidate.

<!-- opencc-sync:v1 fork c75671b112ae7ff8cc08 -->
